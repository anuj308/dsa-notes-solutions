


import net from 'net';
const client = net.createConnection({port:3000},()=>{
    console.log("connected to server");
    client.write("Hello server");
});

client.on("data",(data)=>{
    console.log("server Says :", data.toString());
    client.end();
}) 