





import net from 'net';

const server = net.createServer((socket)=>{
    console.log("Client connected");

    socket.write("Hello Client");
    socket.on("data",(data)=>{
        console.log("Received", data.toString());
    });
    socket.on("end",()=>{
        console.log("client disconnected");
    });
});

server.listen(3000);